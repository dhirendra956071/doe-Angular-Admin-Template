import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-font-awesome-icons',
  templateUrl: './font-awesome-icons.component.html',
  styleUrls: ['./font-awesome-icons.component.scss']
})
export class FontAwesomeIconsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
