import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-avtars-chips',
  templateUrl: './avtars-chips.component.html',
  styleUrls: ['./avtars-chips.component.scss']
})
export class AvtarsChipsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
