import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-media-objects',
  templateUrl: './media-objects.component.html',
  styleUrls: ['./media-objects.component.scss']
})
export class MediaObjectsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
